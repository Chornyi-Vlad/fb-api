# react-facebook-login-example

React - Facebook Login Tutorial & Example

Tutorial and demo available at https://jasonwatmore.com/post/2020/10/25/react-facebook-login-tutorial-example